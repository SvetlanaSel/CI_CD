import psycopg2
import os
import random
import time

print("Waiting for DB to be fully ready...")
time.sleep(5)

conn = psycopg2.connect(
    host=os.getenv("DB_HOST"),
    port=os.getenv("DB_PORT", "5432"),
    dbname=os.getenv("POSTGRES_DB"),
    user=os.getenv("POSTGRES_USER"),
    password=os.getenv("POSTGRES_PASSWORD")
)

cur = conn.cursor()

cur.execute("""
    CREATE TABLE IF NOT EXISTS simple_house_prices (
        id          SERIAL PRIMARY KEY,
        size_m2     INTEGER,          -- площадь дома в м²
        rooms       INTEGER,          -- количество комнат
        age_years   INTEGER,          -- возраст дома
        price       INTEGER           -- цена в тысячах (примерно)
    );
""")

print("Добавляем данные о домах...")

data = [
    (80,  3, 15,  4500),
    (120, 4, 5,   7200),
    (65,  2, 25,  3200),
    (150, 5, 2,   9800),
    (90,  3, 10,  5100),
    (200, 6, 8,  11500),
    (55,  1, 30,  2800),
    (110, 4, 3,   6800),
    (75,  3, 18,  4100),
    (140, 5, 7,   8900),
]

for base_size, base_rooms, base_age, base_price in data * 50:  
    size = base_size + random.randint(-15, 15)
    rooms = base_rooms + random.randint(-1, 1)
    age = base_age + random.randint(-5, 10)
    price = base_price + random.randint(-800, 1200)

    size = max(40, min(250, size))
    rooms = max(1, min(7, rooms))
    age = max(0, min(50, age))
    price = max(2000, min(15000, price))

    cur.execute(
        "INSERT INTO simple_house_prices (size_m2, rooms, age_years, price) VALUES (%s, %s, %s, %s)",
        (size, rooms, age, price)
    )

conn.commit()
print("Данные о ценах на дома загружены!")
cur.close()
conn.close()