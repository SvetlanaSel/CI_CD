import psycopg2
import mlflow
import time

print("ПРОВЕРКА СВЯЗИ МЕЖДУ СЕРВИСАМИ")

print("\n1. Проверка подключения к PostgreSQL...")
try:
    conn = psycopg2.connect(
        host="localhost",
        port=5433,
        dbname="mlflowdb",
        user="admin",
        password="admin"
    )
    cur = conn.cursor()
    
    cur.execute("SELECT COUNT(*) FROM simple_house_prices")
    count = cur.fetchone()[0]
    print(f"   Подключение к PostgreSQL успешно")
    print(f"   Записей в таблице simple_house_prices: {count}")
    
    cur.execute("SELECT size_m2, rooms, age_years, price FROM simple_house_prices LIMIT 3")
    print(f"   Примеры данных:")
    for row in cur.fetchall():
        print(f"      площадь: {row[0]}м2, комнат: {row[1]}, возраст: {row[2]} лет, цена: {row[3]} тыс.")
    
    cur.close()
    conn.close()
    
except Exception as e:
    print(f"   Ошибка подключения к PostgreSQL: {e}")
    print("   Убедитесь, что запущен порт-форвардинг: kubectl port-forward deployment/db-deployment 5432:5432")

print("\n2. Проверка подключения к MLflow Server...")
try:
    mlflow.set_tracking_uri("http://localhost:5000")
    
    print(f"   Версия MLflow: {mlflow.__version__}")
    
    experiment_name = "integration_test"
    try:
        experiment_id = mlflow.create_experiment(experiment_name)
        print(f"   Создан новый эксперимент: {experiment_name}")
    except:
        experiment = mlflow.get_experiment_by_name(experiment_name)
        experiment_id = experiment.experiment_id
        print(f"   Используется существующий эксперимент: {experiment_name}")
    
    with mlflow.start_run(experiment_id=experiment_id, run_name="connection_test"):
        mlflow.log_param("test_time", time.strftime("%Y-%m-%d %H:%M:%S"))
        mlflow.log_param("postgres_records", count)
        mlflow.log_metric("connection_success", 1)
        mlflow.log_metric("records_count", count)
        mlflow.log_param("sample_house_size", 80)
        mlflow.log_param("sample_house_price", 4500)
        
        print(f"   Run создан: connection_test")
        print(f"   Метрики и параметры залогированы")
    
    print(f"\nОткройте MLflow UI: http://localhost:5000")
    print(f"   Найдите эксперимент '{experiment_name}' и run 'connection_test'")
    
except Exception as e:
    print(f"   Ошибка подключения к MLflow: {e}")
    print("   Убедитесь, что запущен порт-форвардинг: kubectl port-forward deployment/app-deployment 5000:5000")

print("ПРОВЕРКА ЗАВЕРШЕНА")
